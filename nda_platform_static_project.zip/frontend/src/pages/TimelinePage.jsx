import { useState } from 'react';

export default function TimelinePage() {
  const [ndaId, setNdaId] = useState('');
  const [timeline, setTimeline] = useState([]);

  const fetchTimeline = () => {
    setTimeline([
      { step: '거래 시작', timestamp: '2025-01-01' },
      { step: '계약서 서명', timestamp: '2025-02-01' }
    ]);
  }

  return (
    <div>
      <h2 className="text-xl mb-2">거래 타임라인 시각화</h2>
      <input
        className="border p-1 mr-2"
        placeholder="NDA ID"
        value={ndaId}
        onChange={e => setNdaId(e.target.value)}
      />
      <button className="bg-green-500 text-white px-2 py-1" onClick={fetchTimeline}>불러오기</button>
      <div className="mt-4">
        {timeline.map((t, i) => (
          <div key={i} className="mb-2">
            <div className="font-bold">{t.step}</div>
            <div className="text-sm text-gray-500">{t.timestamp}</div>
          </div>
        ))}
      </div>
    </div>
  );
}