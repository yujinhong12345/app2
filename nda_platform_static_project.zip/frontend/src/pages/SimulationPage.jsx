import { useState } from 'react';

export default function SimulationPage() {
  const [ndaId, setNdaId] = useState('');
  const [result, setResult] = useState('');

  const simulate = () => {
    setResult("모의소송 시뮬레이션 결과는 서버에 의존합니다.");
  }

  return (
    <div>
      <h2 className="text-xl mb-2">모의소송 시뮬레이션</h2>
      <input
        className="border p-1 mr-2"
        placeholder="NDA ID"
        value={ndaId}
        onChange={e => setNdaId(e.target.value)}
      />
      <button className="bg-purple-500 text-white px-2 py-1" onClick={simulate}>시뮬레이션 실행</button>
      <pre className="bg-gray-100 p-2 mt-2">{result}</pre>
    </div>
  );
}